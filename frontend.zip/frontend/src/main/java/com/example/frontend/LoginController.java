package com.example.frontend;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

public class LoginController {

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private void handleLogin() {
        String email = emailField.getText();
        String password = passwordField.getText();

        if (email.isEmpty() || password.isEmpty()) {
            showAlert("Vui lòng nhập đầy đủ email và mật khẩu.");
            return;
        }

        try {
            String json = String.format("{\"email\":\"%s\", \"password\":\"%s\"}", email, password);

            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(ApiConstants.LOGIN_API))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                showAlert("Đăng nhập thành công!");
                // Xử lý logic sau đăng nhập
            } else {
                showAlert("Đăng nhập thất bại: " + response.body());
            }

        } catch (Exception e) {
            showAlert("Lỗi kết nối: " + e.getMessage());
        }
    }

    @FXML
    private void handleForgotPassword() {
        showAlert("Chức năng quên mật khẩu chưa được triển khai.");
    }

    @FXML
    private void handleClose() {
        System.exit(0);
    }

    private void showAlert(String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Thông báo");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}