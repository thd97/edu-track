package com.example.frontend;

public class ApiConstants {
    public static final String BASE_URL = "http://localhost:3004";
    public static final String LOGIN_API = BASE_URL + "/api/login";
}
